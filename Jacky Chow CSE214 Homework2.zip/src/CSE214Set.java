public interface CSE214Set<E> {
    int size();
    boolean contains(E o);
    boolean add(E e);
}
